create
    definer = root@localhost function getOrders(status varchar(15), fromDate date, upTo date) returns int deterministic
BEGIN
DECLARE Totalcount INT;
SELECT COUNT(orderNumber) FROM orders WHERE status = status and orderDate BETWEEN fromDate and upTo INTO Totalcount;
RETURN Totalcount;
END;


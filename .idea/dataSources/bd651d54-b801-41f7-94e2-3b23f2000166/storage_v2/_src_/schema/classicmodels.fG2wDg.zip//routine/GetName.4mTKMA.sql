create
    definer = root@localhost procedure GetName(IN nameIN varchar(255))
BEGIN
    SELECT
      *
    FROM
      `customers`
    WHERE
      customerName = nameIN;
END;

